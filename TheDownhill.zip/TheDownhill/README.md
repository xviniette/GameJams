# The Downhill
## [Play on itch.io](https://xviniette.itch.io/the-downhill)
![](https://raw.githubusercontent.com/xviniette/GameJams/gh-pages/TheDownhill/TheDownhill.gif)
 - Game Jam : [Minimalistic Jam](https://itch.io/jam/minimalistic-jam)
 - Date : 09/07/2017
 
> Moon Conquest is a running game in space ! Leave the Earth and reach the farest Moon !
> Click or Tap to take off !
> Developed in 6 hours for the #RemakeJam !

[Play on Github](https://xviniette.github.io/GameJams/TheDownhill/)